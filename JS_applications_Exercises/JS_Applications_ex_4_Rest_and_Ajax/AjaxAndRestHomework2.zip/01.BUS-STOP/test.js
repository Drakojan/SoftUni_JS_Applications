let a = {4: 13, 12: 6, 18: 7}

for (bus in a) {

    console.log(`bus ${bus} arrives in ${a[bus]} minutes`);

}