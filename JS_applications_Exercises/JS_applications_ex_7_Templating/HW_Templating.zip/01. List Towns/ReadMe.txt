If you input towns as per the condition of the task you'll get them displayed.
If you leave the input blank and just press load you'll get list of
all countries from an API.

Also the tasks needs the file handlebars.min.js to be in the same folder as the task folders to work properly