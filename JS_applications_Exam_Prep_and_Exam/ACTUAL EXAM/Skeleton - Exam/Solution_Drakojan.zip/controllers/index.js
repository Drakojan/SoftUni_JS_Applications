import home from './home.js'
import article from './article.js'
import user from './user.js'

export default {

    home,
    article,
    user
}