// fill in info for your firebase firestore DB below if you want to link the app to your own DB
var firebaseConfig = {
    apiKey: "AIzaSyADJSwqX7Xp-C8k4-MXkLKb44aasCiEegc",
    authDomain: "workplace-a2c03.firebaseapp.com",
    databaseURL: "https://workplace-a2c03.firebaseio.com",
    projectId: "workplace-a2c03",
    storageBucket: "workplace-a2c03.appspot.com",
    messagingSenderId: "1006265658566",
    appId: "1:1006265658566:web:b39d20613f89d949a4fbc7"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  