import article from "./article.js";
import user from "./user.js";

export default {
    article,
    user
}